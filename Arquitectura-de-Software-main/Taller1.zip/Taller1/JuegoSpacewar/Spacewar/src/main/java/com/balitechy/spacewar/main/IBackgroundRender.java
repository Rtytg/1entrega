package com.balitechy.spacewar.main;

import java.awt.Canvas;
import java.awt.Graphics;

public interface IBackgroundRender {
    void renderBackground(Graphics g, Canvas c);
}
