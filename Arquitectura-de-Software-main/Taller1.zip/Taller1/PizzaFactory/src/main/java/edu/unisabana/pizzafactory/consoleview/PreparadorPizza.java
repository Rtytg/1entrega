package edu.unisabana.pizzafactory.consoleview;

import edu.unisabana.pizzafactory.model.AmasadorPizza;
import edu.unisabana.pizzafactory.model.HorneadorPizza;
import edu.unisabana.pizzafactory.model.MoldeadorPizza;
import edu.unisabana.pizzafactory.model.Ingrediente;
import edu.unisabana.pizzafactory.model.ExcepcionParametrosInvalidos;
import edu.unisabana.pizzafactory.model.Tamano;
import edu.unisabana.pizzafactory.model.Tipo;
import edu.unisabana.pizzafactory.maquina.PizzaFactory;
import edu.unisabana.pizzafactory.maquina.PizzaDelgadaMaquina;
import edu.unisabana.pizzafactory.maquina.PizzaGruesaMaquina;
import edu.unisabana.pizzafactory.maquina.PizzaIntegralMaquina;

import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * 
 *   Creado por Mariana Valle y Juan Pablo Benitez
 * 
 */
public class PreparadorPizza {
    public static void main(String args[]) {
        try {
            Ingrediente[] ingredientes = new Ingrediente[]{new Ingrediente("queso", 1), new Ingrediente("jamon", 2)};
            PreparadorPizza pp = new PreparadorPizza();
            pp.prepararPizza(ingredientes, Tamano.MEDIANO, Tipo.DELGADA);
        } catch (ExcepcionParametrosInvalidos ex) {
            Logger.getLogger(PreparadorPizza.class.getName()).log(Level.SEVERE, "Problema en la preparación de la pizza", ex);
        }
    }

    public void prepararPizza(Ingrediente[] ingredientes, Tamano tam, Tipo tipo) throws ExcepcionParametrosInvalidos {
        PizzaFactory factory;

        if (tipo == Tipo.DELGADA) {
            factory = new PizzaDelgadaMaquina();
        } else if (tipo == Tipo.GRUESA) {
            factory = new PizzaGruesaMaquina();
        } else if (tipo == Tipo.INTEGRAL) {
            factory = new PizzaIntegralMaquina();
        } else {
            throw new ExcepcionParametrosInvalidos("Tipo de pizza inválido: " + tipo);
        }

        AmasadorPizza amasador = factory.crearAmasador();
        MoldeadorPizza moldeador = factory.crearMoldeador();
        HorneadorPizza horneador = factory.crearHorneador();

        amasador.amasar();

        moldeador.moldear(tam);

        aplicarIngredientes(ingredientes);

        horneador.hornear();
    }

    private void aplicarIngredientes(Ingrediente[] ingredientes) {
        Logger.getLogger(PreparadorPizza.class.getName())
                .log(Level.INFO, "Aplicando ingredientes: {0}", Arrays.toString(ingredientes));
    }
}