package edu.unisabana.pizzafactory.model;

import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * 
 *   Creado por Mariana Valle y Juan Pablo Benitez
 * 
*/

public class AmasadorIntegralPizza extends AmasadorPizza {
    @Override
    public void amasar() {
        Logger.getLogger(AmasadorIntegralPizza.class.getName())
              .log(Level.INFO, "Amasando pizza integral.");
    }
}
