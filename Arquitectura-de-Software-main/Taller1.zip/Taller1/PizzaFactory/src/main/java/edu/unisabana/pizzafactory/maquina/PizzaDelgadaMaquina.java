package edu.unisabana.pizzafactory.maquina;

import edu.unisabana.pizzafactory.model.AmasadorDelgadaPizza;
import edu.unisabana.pizzafactory.model.HorneadorDelgadaPizza;
import edu.unisabana.pizzafactory.model.MoldeadorDelgadaPizza;
import edu.unisabana.pizzafactory.model.AmasadorPizza;
import edu.unisabana.pizzafactory.model.HorneadorPizza;
import edu.unisabana.pizzafactory.model.MoldeadorPizza;

/*
 * 
 *   Creado por Mariana Valle y Juan Pablo Benitez
 * 
*/

public class PizzaDelgadaMaquina extends PizzaFactory {

    @Override
    public AmasadorPizza crearAmasador() {
        return new AmasadorDelgadaPizza();
    }

    @Override
    public MoldeadorPizza crearMoldeador() {
        return new MoldeadorDelgadaPizza();
    }

    @Override
    public HorneadorPizza crearHorneador() {
        return new HorneadorDelgadaPizza();
    }
}