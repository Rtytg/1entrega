package edu.unisabana.pizzafactory.model;

/*
 * 
 *   Creado por Mariana Valle y Juan Pablo Benitez
 * 
*/

public abstract class AmasadorPizza {
        public abstract void amasar();
}
