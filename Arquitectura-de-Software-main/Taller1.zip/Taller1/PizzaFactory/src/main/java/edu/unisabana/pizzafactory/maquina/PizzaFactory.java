package edu.unisabana.pizzafactory.maquina;

import edu.unisabana.pizzafactory.model.AmasadorPizza;
import edu.unisabana.pizzafactory.model.MoldeadorPizza;
import edu.unisabana.pizzafactory.model.HorneadorPizza;

/*
 * 
 *   Creado por Mariana Valle y Juan Pablo Benitez
 * 
*/

public abstract class PizzaFactory {
    public abstract AmasadorPizza crearAmasador();
    public abstract MoldeadorPizza crearMoldeador();
    public abstract HorneadorPizza crearHorneador();   
} 