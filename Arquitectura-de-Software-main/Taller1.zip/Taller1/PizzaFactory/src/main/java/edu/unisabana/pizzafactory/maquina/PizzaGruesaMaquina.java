package edu.unisabana.pizzafactory.maquina;

import edu.unisabana.pizzafactory.model.AmasadorGruesaPizza;
import edu.unisabana.pizzafactory.model.HorneadorGruesaPizza;
import edu.unisabana.pizzafactory.model.MoldeadorGruesaPizza;
import edu.unisabana.pizzafactory.model.AmasadorPizza;
import edu.unisabana.pizzafactory.model.HorneadorPizza;
import edu.unisabana.pizzafactory.model.MoldeadorPizza;

/*
 * 
 *   Creado por Mariana Valle y Juan Pablo Benitez
 * 
*/

public class PizzaGruesaMaquina extends PizzaFactory {

    @Override
    public AmasadorPizza crearAmasador() {
        return new AmasadorGruesaPizza();
    }

    @Override
    public MoldeadorPizza crearMoldeador() {
        return new MoldeadorGruesaPizza();
    }

    @Override
    public HorneadorPizza crearHorneador() {
        return new HorneadorGruesaPizza();
    }
}