package edu.unisabana.pizzafactory.model;

import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * 
 *   Creado por Mariana Valle y Juan Pablo Benitez
 * 
*/

public class AmasadorGruesaPizza extends AmasadorPizza {
    @Override
    public void amasar() {
        Logger.getLogger(AmasadorGruesaPizza.class.getName())
              .log(Level.INFO, "Amasando pizza gruesa.");
    }
}