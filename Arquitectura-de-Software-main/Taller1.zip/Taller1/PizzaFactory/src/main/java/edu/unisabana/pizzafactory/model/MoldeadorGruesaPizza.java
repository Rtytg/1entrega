package edu.unisabana.pizzafactory.model;

import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * 
 *   Creado por Mariana Valle y Juan Pablo Benitez
 * 
*/

public class MoldeadorGruesaPizza extends MoldeadorPizza {
    @Override
    public void moldear(Tamano tamano) {
        if (tamano == Tamano.PEQUENO) {
            Logger.getLogger(MoldeadorGruesaPizza.class.getName())
                    .log(Level.INFO, "Moldeando pizza gruesa pequeña.");
        } else if (tamano == Tamano.MEDIANO) {
            Logger.getLogger(MoldeadorGruesaPizza.class.getName())
                    .log(Level.INFO, "Moldeando pizza gruesa mediana.");
        } else if (tamano == Tamano.GRANDE) {
            Logger.getLogger(MoldeadorGruesaPizza.class.getName())
                    .log(Level.INFO, "Moldeando pizza gruesa grande.");
        }else {
            Logger.getLogger(MoldeadorGruesaPizza.class.getName())
                    .log(Level.SEVERE, "Tamaño de pizza no válido: " + tamano);
        }
    }
}
