package edu.unisabana.pizzafactory.maquina;

import edu.unisabana.pizzafactory.model.AmasadorIntegralPizza;
import edu.unisabana.pizzafactory.model.HorneadorIntegralPizza;
import edu.unisabana.pizzafactory.model.MoldeadorIntegralPizza;
import edu.unisabana.pizzafactory.model.AmasadorPizza;
import edu.unisabana.pizzafactory.model.HorneadorPizza;
import edu.unisabana.pizzafactory.model.MoldeadorPizza;

/*
 * 
 *   Creado por Mariana Valle y Juan Pablo Benitez
 * 
*/

public class PizzaIntegralMaquina extends PizzaFactory {

    @Override
    public AmasadorPizza crearAmasador() {
        return new AmasadorIntegralPizza();
    }

    @Override
    public MoldeadorPizza crearMoldeador() {
        return new MoldeadorIntegralPizza();
    }

    @Override
    public HorneadorPizza crearHorneador() {
        return new HorneadorIntegralPizza();
    }
}