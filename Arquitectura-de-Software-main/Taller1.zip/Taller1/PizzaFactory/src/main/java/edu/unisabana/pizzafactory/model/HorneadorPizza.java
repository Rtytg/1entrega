package edu.unisabana.pizzafactory.model;

/*
 * 
 *   Creado por Mariana Valle y Juan Pablo Benitez
 * 
*/

public abstract class HorneadorPizza {
    public abstract void hornear();
}
    
