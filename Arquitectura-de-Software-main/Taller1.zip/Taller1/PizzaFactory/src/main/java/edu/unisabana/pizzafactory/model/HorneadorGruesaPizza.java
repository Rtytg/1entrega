package edu.unisabana.pizzafactory.model;

import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * 
 *   Creado por Mariana Valle y Juan Pablo Benitez
 * 
*/

public class HorneadorGruesaPizza extends HorneadorPizza {
    @Override
    public void hornear() {
        Logger.getLogger(HorneadorGruesaPizza.class.getName())
              .log(Level.INFO, "Horneando pizza gruesa.");
    }
}
