
package edu.unisabana.pizzafactory.model;

/*
 * 
 *   Creado por Mariana Valle y Juan Pablo Benitez
 * 
 */
public enum Tamano {
    
    GRANDE,
    MEDIANO, 
    PEQUENO
    
}
