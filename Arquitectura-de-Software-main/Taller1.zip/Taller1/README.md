# Universidad de la Sabana
## Diseño y Arquitectura de Software
### Taller 1 
Integrantes: Mariana Valle y Juan Pablo Benitez

# Parte I:


# Parte II: